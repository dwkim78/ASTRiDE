import os

import pylab as pl

from astropy.io import fits


class ASTRiDE:
    def __init__(self, filename):
        """
        Initialize.
        :param filename: A fits filename.
        """

        hdulist = fits.open(filename)
        data = hdulist[0].data
        hdulist.close()

        # Raw image data.
        self.raw_image = data
        # Background map.
        self.background_map = None
        # Background removed image data.
        self.image = None
        # Edges detected.
        self.raw_edges = None
        # Filtered edges, so streaks, by their morphologies
        # and also linked (i.e. connected).
        self.streaks = None

    def remove_background(self):
        pass

    def detect_streaks(self):
        pass

    def plot_figures(self, path):
        """
        Save figures of detected streaks under the 'path' folder.
        :param path:
        :return:
        """
        if not os.path.exists(path):
            os.makedirs(path)

    def write_outputs(self, path):
        """
        Write information of detected streaks under the 'path' folder.
        :param path:
        :return:
        """
        if not os.path.exists(path):
            os.makedirs(path)



if __name__ == '__main__':
    #astride = ASTRiDE('/Users/kim/Dropbox/python/ASTRiDE/astride/datasets/samples/long.fits')
    astride = ASTRiDE('./datasets/samples/long.fits')
