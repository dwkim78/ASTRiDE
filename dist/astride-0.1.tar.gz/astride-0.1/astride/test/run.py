import numpy as np
import pylab as pl
from astropy.stats import sigma_clipped_stats
from photutils.background import Background
from skimage import measure

from photutils import daofind, irafstarfind
from photutils import datasets

from astride.datasets.base import read_fits
from astride.utils.edge import EDGE


def run():
    contour_threshold = 3.

    data = read_fits().astype(np.float64)
    #data = datasets.load_star_image().data.astype(np.float64)

    # Get background map and subtract.
    bkg = Background(data, (50, 50), method='median')
    data -= bkg.background

    # Find contours.
    # Returned contours is the list of [row, columns] (i.e. [y, x])
    contours = measure.find_contours(
            data, bkg.background_rms_median * contour_threshold,
            fully_connected='high'
                                     )
    # Quantify shapes of the contours and save them as 'edges'.
    edge = EDGE(contours)
    edge.quantify()
    edge.filter_edges()
    edge.connect_edges()
    edges = edge.get_edges()

    # Find the boxes to plot.
    def find_box(n, edges, xs, ys):
        """
        Recursive function that defines a box surrounding
        one or more edges that are connected to each other.
        :param n: Index of edge currently checking.
        :param edges: edges.
        :param xs: x min and max coordinates.
        :param ys: y min and max coordinates.
        :return: x and y coordinates for plot plotting.
        """
        # Add current coordinates.
        current_edge = [edge for edge in edges if edge['index'] == n][0]
        current_edge['box_plotted'] = True
        xs.append([current_edge['x_min'], current_edge['x_max']])
        ys.append([current_edge['y_min'], current_edge['y_max']])

        # If connected with other edge.
        if current_edge['connectivity'] != -1:
            find_box(current_edge['connectivity'], edges, xs, ys)
        # Otherwise.
        else:
            return xs, ys

    # Plot the image.
    cut_threshold = 5.
    plot_data = data.copy()
    mean, med, std = sigma_clipped_stats(data, sigma=3.0, iters=5)
    plot_data[np.where(data > med + cut_threshold * std)] = \
        med + cut_threshold * std
    plot_data[np.where(data < med - cut_threshold * std)] = \
        med - cut_threshold * std
    pl.figure(figsize=(12, 9))
    pl.imshow(plot_data, origin='lower', cmap='gray')

    # Source detection to remove stars before streak detection.
    # We DO NOT use any source detection methods because
    # such methods often consider streaks as a long continuous
    # row of stars.
    #FWHM = 3.
    #detection_threshold = 3.
    #sources = daofind(data, threshold=std * detection_threshold, fwhm=FWHM)
    ##sources = irafstarfind(data, threshold=std * detection_threshold, fwhm=FWHM)
    #pl.plot(sources['xcentroid'], sources['ycentroid'], 'r.')

    # Plot all contours.
    for n, edge in enumerate(edges):
        pl.plot(edge['x'], edge['y'])
        #pl.text(edge['x'][0], edge['y'][1],
        #        'A: %.1f, SF: %.1f, RD: %.1f, slope: %.1f' %
        #        (edge['area'], edge['shape_factor'], edge['radius_deviation'],
        #         edge['slope_angle']))

        pl.text(edge['x'][0], edge['y'][1],
                '%d' % (edge['index']), color='b', fontsize=15)

        # Plot fitted line.
        #x = np.linspace(0, data.shape[0], 10)
        #y = edge['slope'] * x + edge['intercept']
        #pl.plot(x, y)

    # Plot boxes.
    # Box margin in pixel.
    box_margin = 10
    for n, edge in enumerate(edges):
        # plot boxes around the edge.
        if not edge['box_plotted']:
            # Define the box to plot.
            xs = []
            ys = []
            find_box(edge['index'], edges, xs, ys)
            x_min = max(np.min(xs) - box_margin, 0)
            x_max = min(np.max(xs) + box_margin, data.shape[0])
            y_min = max(np.min(ys) - box_margin, 0)
            y_max = min(np.max(ys) + box_margin, data.shape[1])
            box_x = [x_min, x_min, x_max, x_max]
            box_y = [y_min, y_max, y_max, y_min]
            pl.fill(box_x, box_y, ls='--', fill=False, ec='r', lw=2)
            edge['box_plotted'] = True

    pl.xlabel('X/pixel')
    pl.ylabel('Y/pixel')
    pl.axis([0, data.shape[0], 0, data.shape[1]])
    pl.savefig('all.png')

    # Plot all individual edges (connected).
    for n, edge in enumerate(edges):
        # Reset.
        edge['box_plotted'] = False

    for n, edge in enumerate(edges):
        if not edge['box_plotted']:
            # Define the box to plot.
            xs = []
            ys = []
            find_box(edge['index'], edges, xs, ys)
            x_min = max(np.min(xs) - box_margin, 0)
            x_max = min(np.max(xs) + box_margin, data.shape[0])
            y_min = max(np.min(ys) - box_margin, 0)
            y_max = min(np.max(ys) + box_margin, data.shape[1])
            edge['box_plotted'] = True
            pl.axis([x_min, x_max, y_min, y_max])
            pl.savefig('%d.png' % (edge['index']))

    # Write an output text file.
    fp = open('streaks.txt', 'w')
    fp.writelines('#ID x_center y_center area perimeter shape_factor ' +
                  'radius_deviation slope_angle intercept connectivity\n')
    for n, edge in enumerate(edges):
        line = '%2d %7.2f %7.2f %6.1f %6.1f %6.3f %6.2f %5.2f %7.2f %2d\n' % \
               (
                   edge['index'], edge['x_center'], edge['y_center'],
                   edge['area'], edge['perimeter'], edge['shape_factor'],
                   edge['radius_deviation'], edge['slope_angle'],
                   edge['intercept'], edge['connectivity']
               )
        fp.writelines(line)
    fp.close()


if __name__ == '__main__':
    run()